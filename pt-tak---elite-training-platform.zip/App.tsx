
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import HostDashboard from './components/HostDashboard';
import UserDashboard from './components/UserDashboard';
import { User, TrainingProgram, CompletionRecord } from './types';
import { MOCK_USERS, INITIAL_PROGRAMS } from './constants';
import { Dumbbell, Mail, Lock, User as UserIcon, ShieldCheck, ArrowRight, Loader2 } from 'lucide-react';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [programs, setPrograms] = useState<TrainingProgram[]>(INITIAL_PROGRAMS);
  const [completions, setCompletions] = useState<CompletionRecord[]>([]);
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<'host' | 'user'>('user');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const storedUsers = localStorage.getItem('titan_users');
    if (!storedUsers) {
      localStorage.setItem('titan_users', JSON.stringify(MOCK_USERS.map(u => ({ ...u, password: 'password123' }))));
    }
    
    const sessionUser = sessionStorage.getItem('titan_session');
    if (sessionUser) {
      setUser(JSON.parse(sessionUser));
    }
  }, []);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    await new Promise(resolve => setTimeout(resolve, 800));

    const storedUsersRaw = localStorage.getItem('titan_users');
    const users = storedUsersRaw ? JSON.parse(storedUsersRaw) : [];

    if (authMode === 'signup') {
      if (users.find((u: any) => u.email === email)) {
        setError('An account with this email already exists.');
        setIsLoading(false);
        return;
      }

      const newUser = {
        id: Math.random().toString(36).substr(2, 9),
        name,
        email,
        password,
        role,
        avatar: `https://picsum.photos/seed/${email}/100`
      };

      users.push(newUser);
      localStorage.setItem('titan_users', JSON.stringify(users));
      
      const { password: _, ...userWithoutPassword } = newUser;
      setUser(userWithoutPassword as User);
      sessionStorage.setItem('titan_session', JSON.stringify(userWithoutPassword));
    } else {
      const foundUser = users.find((u: any) => u.email === email && u.password === password);
      if (foundUser) {
        const { password: _, ...userWithoutPassword } = foundUser;
        setUser(userWithoutPassword as User);
        sessionStorage.setItem('titan_session', JSON.stringify(userWithoutPassword));
      } else {
        setError('Invalid email or password.');
      }
    }
    setIsLoading(false);
  };

  const handleLogout = () => {
    setUser(null);
    sessionStorage.removeItem('titan_session');
    setEmail('');
    setPassword('');
    setName('');
  };

  const handleAddProgram = (p: TrainingProgram) => {
    setPrograms(prev => [p, ...prev]);
  };

  const handleCompleteWorkout = (workoutId: string) => {
    const newCompletion: CompletionRecord = {
      id: Math.random().toString(),
      userId: user?.id || '',
      workoutId,
      programId: programs[0].id,
      date: new Date().toISOString(),
      completed: true
    };
    setCompletions(prev => [...prev, newCompletion]);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 relative overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-100 rounded-full blur-[120px] opacity-50" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-slate-200 rounded-full blur-[120px] opacity-50" />

        <div className="max-w-md w-full relative z-10">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-slate-900 rounded-2xl text-white shadow-2xl mb-6">
              <Dumbbell className="w-6 h-6" />
              <span className="text-xl font-black tracking-tighter">PT TAK</span>
            </div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight">
              {authMode === 'login' ? 'Welcome Back' : 'Create Account'}
            </h1>
            <p className="text-slate-500 mt-2 font-medium">
              {authMode === 'login' 
                ? 'Sign in to access your personal training plans.' 
                : 'Join PT TAK to start your custom fitness journey.'}
            </p>
          </div>

          <div className="bg-white p-8 rounded-[2.5rem] shadow-2xl shadow-slate-200 border border-slate-100">
            <form onSubmit={handleAuth} className="space-y-4">
              {authMode === 'signup' && (
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-400 uppercase ml-1">Full Name</label>
                  <div className="relative">
                    <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      required
                      type="text"
                      placeholder="Alex Johnson"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-slate-50 border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-blue-500 transition-all outline-none font-medium text-slate-900"
                    />
                  </div>
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-400 uppercase ml-1">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    required
                    type="email"
                    placeholder="alex@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-50 border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-blue-500 transition-all outline-none font-medium text-slate-900"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-400 uppercase ml-1">Password</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    required
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-slate-50 border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-blue-500 transition-all outline-none font-medium text-slate-900"
                  />
                </div>
              </div>

              {authMode === 'signup' && (
                <div className="pt-2">
                  <label className="text-xs font-bold text-slate-400 uppercase ml-1 mb-2 block">I am a...</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setRole('user')}
                      className={`py-3 rounded-2xl font-bold text-sm transition-all border-2 ${
                        role === 'user' ? 'bg-blue-600 border-blue-600 text-white shadow-lg shadow-blue-200' : 'bg-slate-50 border-slate-100 text-slate-500 hover:border-blue-200'
                      }`}
                    >
                      Trainee
                    </button>
                    <button
                      type="button"
                      onClick={() => setRole('host')}
                      className={`py-3 rounded-2xl font-bold text-sm transition-all border-2 ${
                        role === 'host' ? 'bg-slate-900 border-slate-900 text-white shadow-lg' : 'bg-slate-50 border-slate-100 text-slate-500'
                      }`}
                    >
                      Host / Coach
                    </button>
                  </div>
                </div>
              )}

              {error && (
                <div className="p-4 bg-red-50 text-red-600 text-sm font-semibold rounded-2xl flex items-center gap-2 border border-red-100">
                  <ShieldCheck className="w-4 h-4 flex-shrink-0" />
                  {error}
                </div>
              )}

              <button
                disabled={isLoading}
                className="w-full bg-blue-600 text-white py-4 rounded-2xl font-black text-lg shadow-xl shadow-blue-200 hover:bg-blue-700 hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2 mt-4 disabled:opacity-70"
              >
                {isLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                  <>
                    {authMode === 'login' ? 'Sign In' : 'Create Account'}
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>
            </form>

            <div className="mt-8 text-center">
              <button
                onClick={() => {
                  setAuthMode(authMode === 'login' ? 'signup' : 'login');
                  setError('');
                }}
                className="text-slate-500 font-bold hover:text-blue-600 transition-colors"
              >
                {authMode === 'login' ? "Don't have an account? Create one" : "Already have an account? Sign in"}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <Layout 
      user={user} 
      onLogout={handleLogout} 
      activeTab={activeTab} 
      setActiveTab={setActiveTab}
    >
      {user.role === 'host' ? (
        <HostDashboard 
          programs={programs} 
          trainees={MOCK_USERS.filter(u => u.role === 'user')}
          onAddProgram={handleAddProgram}
        />
      ) : (
        <UserDashboard 
          program={programs.find(p => p.assignedUserIds.includes(user.id)) || null} 
          completions={completions.filter(c => c.userId === user.id)}
          onComplete={handleCompleteWorkout}
        />
      )}
    </Layout>
  );
};

export default App;
