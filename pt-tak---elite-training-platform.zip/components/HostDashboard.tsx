
import React from 'react';
import { Plus, Users, ClipboardList, Target, Sparkles, Loader2 } from 'lucide-react';
import { TrainingProgram, User } from '../types';
import { generateProgramWithAI } from '../services/geminiService';

interface HostDashboardProps {
  programs: TrainingProgram[];
  trainees: User[];
  onAddProgram: (program: TrainingProgram) => void;
}

const HostDashboard: React.FC<HostDashboardProps> = ({ programs, trainees, onAddProgram }) => {
  const [isGenerating, setIsGenerating] = React.useState(false);

  const handleAISuggestion = async () => {
    setIsGenerating(true);
    try {
      const suggested = await generateProgramWithAI("Strength and Conditioning", "3", "Intermediate");
      const newProgram: TrainingProgram = {
        ...suggested,
        id: `p-ai-${Date.now()}`,
        hostId: '1',
        assignedUserIds: [],
        difficulty: suggested.difficulty || 'Intermediate',
        durationWeeks: suggested.durationWeeks || 4,
        workouts: (suggested.workouts || []).map((w: any, idx: number) => ({
          ...w,
          id: `w-ai-${Date.now()}-${idx}`
        }))
      };
      onAddProgram(newProgram);
    } catch (error) {
      console.error("AI Generation failed", error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100 flex items-center gap-6">
          <div className="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600">
            <Users className="w-7 h-7" />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Active Trainees</p>
            <p className="text-3xl font-bold text-slate-900">{trainees.length}</p>
          </div>
        </div>
        <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100 flex items-center gap-6">
          <div className="w-14 h-14 bg-purple-50 rounded-2xl flex items-center justify-center text-purple-600">
            <ClipboardList className="w-7 h-7" />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Active Programs</p>
            <p className="text-3xl font-bold text-slate-900">{programs.length}</p>
          </div>
        </div>
        <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100 flex items-center gap-6">
          <div className="w-14 h-14 bg-green-50 rounded-2xl flex items-center justify-center text-green-600">
            <Target className="w-7 h-7" />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Compliance Rate</p>
            <p className="text-3xl font-bold text-slate-900">84%</p>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-4">
        <button className="flex-1 bg-blue-600 text-white p-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 hover:bg-blue-700 transition-all shadow-lg shadow-blue-200">
          <Plus className="w-5 h-5" />
          Create New Program
        </button>
        <button 
          onClick={handleAISuggestion}
          disabled={isGenerating}
          className="flex-1 bg-white text-slate-900 border border-slate-200 p-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 hover:bg-slate-50 transition-all shadow-sm"
        >
          {isGenerating ? (
            <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
          ) : (
            <Sparkles className="w-5 h-5 text-blue-600" />
          )}
          AI Smart Suggest
        </button>
      </div>

      {/* Program List */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-slate-900">Training Programs</h2>
          <button className="text-sm font-bold text-blue-600 hover:underline">View All</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {programs.map(program => (
            <div key={program.id} className="bg-white border border-slate-100 rounded-3xl overflow-hidden hover:shadow-xl transition-all group">
              <div className="relative h-32 bg-slate-100">
                <img src={`https://picsum.photos/seed/${program.id}/400/200`} className="w-full h-full object-cover opacity-80" alt="" />
                <div className="absolute top-4 left-4">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-white bg-slate-900/80 backdrop-blur-md px-2 py-1 rounded">
                    {program.difficulty}
                  </span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="font-bold text-slate-900 text-lg mb-2">{program.title}</h3>
                <p className="text-xs text-slate-500 line-clamp-2 mb-6">{program.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex -space-x-2">
                    {program.assignedUserIds.map((uid, i) => (
                      <img key={uid} src={`https://picsum.photos/seed/${uid}/40`} className="w-8 h-8 rounded-full border-2 border-white" alt="" />
                    ))}
                  </div>
                  <button className="text-xs font-bold text-blue-600">Edit Program</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Recent Activity */}
      <section>
        <h2 className="text-xl font-bold text-slate-900 mb-6">Recent Activity</h2>
        <div className="bg-white rounded-3xl border border-slate-100 overflow-hidden shadow-sm">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Trainee</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Workout</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Date</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {trainees.map(trainee => (
                <tr key={trainee.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <img src={trainee.avatar} className="w-8 h-8 rounded-full" alt="" />
                      <span className="text-sm font-bold text-slate-900">{trainee.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">Push Session A</td>
                  <td className="px-6 py-4 text-sm text-slate-600">2 hours ago</td>
                  <td className="px-6 py-4">
                    <span className="px-3 py-1 text-[10px] font-bold rounded-full bg-green-100 text-green-700 uppercase">Completed</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};

export default HostDashboard;
