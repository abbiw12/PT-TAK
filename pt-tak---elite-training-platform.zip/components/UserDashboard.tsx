
import React from 'react';
import { CheckCircle2, Circle, Clock, Flame, Trophy, Play, Shield, Target } from 'lucide-react';
import { TrainingProgram, Workout, CompletionRecord } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface UserDashboardProps {
  program: TrainingProgram | null;
  completions: CompletionRecord[];
  onComplete: (workoutId: string) => void;
}

const UserDashboard: React.FC<UserDashboardProps> = ({ program, completions, onComplete }) => {
  const chartData = [
    { name: 'MON', count: 1 },
    { name: 'TUE', count: 0 },
    { name: 'WED', count: 1 },
    { name: 'THU', count: 0 },
    { name: 'FRI', count: 1 },
    { name: 'SAT', count: 0 },
    { name: 'SUN', count: 0 },
  ];

  if (!program) {
    return (
      <div className="text-center py-20 bg-white rounded-3xl border border-slate-100 max-w-2xl mx-auto shadow-xl">
        <Target className="w-16 h-16 text-slate-200 mx-auto mb-6" />
        <h2 className="text-2xl font-bold text-slate-900">No Program Assigned</h2>
        <p className="text-slate-500 mt-2">Your coach will assign a training plan soon.</p>
      </div>
    );
  }

  const nextWorkout = program.workouts[0];

  return (
    <div className="space-y-8">
      {/* Hero Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-slate-900 text-white p-8 rounded-[2rem] col-span-1 md:col-span-2 relative overflow-hidden shadow-2xl">
          <div className="relative z-10">
            <h2 className="text-blue-400 text-sm font-bold uppercase tracking-wider mb-2">Current Program</h2>
            <h3 className="text-3xl font-bold mb-6">{program.title}</h3>
            <div className="flex items-center gap-8">
              <div className="flex flex-col">
                <span className="text-3xl font-bold">12 / 24</span>
                <span className="text-xs text-slate-400">Workouts Done</span>
              </div>
              <div className="h-10 w-[1px] bg-slate-800" />
              <div className="flex flex-col">
                <span className="text-3xl font-bold text-blue-400">52%</span>
                <span className="text-xs text-slate-400">Progress</span>
              </div>
            </div>
          </div>
          <Target className="absolute -right-4 -bottom-4 w-40 h-40 text-white/5 -rotate-12" />
        </div>
        
        <div className="bg-white p-6 rounded-[2rem] border border-slate-100 flex flex-col justify-center items-center text-center shadow-sm">
          <div className="w-12 h-12 bg-red-50 rounded-2xl flex items-center justify-center text-red-500 mb-4">
            <Flame className="w-6 h-6" />
          </div>
          <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Streak</p>
          <p className="text-2xl font-bold text-slate-900">05 Days</p>
        </div>

        <div className="bg-white p-6 rounded-[2rem] border border-slate-100 flex flex-col justify-center items-center text-center shadow-sm">
          <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-500 mb-4">
            <Clock className="w-6 h-6" />
          </div>
          <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Next Session</p>
          <p className="text-2xl font-bold text-slate-900">Tomorrow</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
              <Play className="w-5 h-5 text-blue-600" />
              Today's Session
            </h2>
            
            <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 mb-8 pb-6 border-b border-slate-50">
                <div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-1">{nextWorkout.title}</h3>
                  <div className="flex items-center gap-4 text-slate-500 text-sm">
                    <span className="flex items-center gap-1.5 font-medium">
                       <Shield className="w-4 h-4" />
                       {nextWorkout.exercises.length} Exercises
                    </span>
                    <span>•</span>
                    <span className="font-medium">45 MIN</span>
                  </div>
                </div>
                <button 
                  onClick={() => onComplete(nextWorkout.id)}
                  className="bg-blue-600 text-white px-6 py-3 rounded-xl font-bold text-sm hover:bg-blue-700 transition-all flex items-center gap-2"
                >
                  Start Workout
                </button>
              </div>

              <div className="space-y-3">
                {nextWorkout.exercises.map((ex, idx) => (
                  <div key={ex.id} className="flex items-center gap-4 p-4 hover:bg-slate-50 rounded-2xl transition-all group">
                    <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center font-bold text-slate-400 group-hover:text-blue-600">
                      {idx + 1}
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-slate-900">{ex.name}</p>
                      <p className="text-xs text-slate-500">{ex.sets} Sets • {ex.reps} Reps</p>
                    </div>
                    {completions.some(c => c.workoutId === nextWorkout.id) ? (
                      <CheckCircle2 className="w-6 h-6 text-green-500" />
                    ) : (
                      <Circle className="w-6 h-6 text-slate-200" />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-6">Weekly Activity</h2>
            <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                  <Tooltip />
                  <Area type="monotone" dataKey="count" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorCount)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </section>
        </div>

        <div className="space-y-8">
          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
               <Trophy className="w-5 h-5 text-yellow-500" />
               Performance
            </h2>
            <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 text-center">
              <div className="relative w-32 h-32 mx-auto mb-6">
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  <circle className="text-slate-100 stroke-current" strokeWidth="10" fill="transparent" r="40" cx="50" cy="50" />
                  <circle 
                    className="text-blue-600 stroke-current" 
                    strokeWidth="10" 
                    strokeLinecap="round" 
                    fill="transparent" 
                    r="40" cx="50" cy="50" 
                    strokeDasharray="251.2" 
                    strokeDashoffset={251.2 - (251.2 * 0.52)}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center flex-col">
                  <span className="text-2xl font-bold text-slate-900">52%</span>
                </div>
              </div>
              <div className="space-y-4 text-left pt-4 border-t border-slate-50">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-500">Completed</span>
                  <span className="text-sm font-bold text-slate-900">12 Sessions</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-500">Average Duration</span>
                  <span className="text-sm font-bold text-slate-900">48 Min</span>
                </div>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-6">Upcoming</h2>
            <div className="space-y-3">
              {program.workouts.slice(1, 4).map(w => (
                <div key={w.id} className="p-4 bg-white border border-slate-100 rounded-2xl flex items-center gap-4 hover:shadow-md transition-all cursor-pointer">
                  <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center font-bold text-slate-400 text-xs">
                    {w.day.substring(0,3)}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">{w.title}</h4>
                    <p className="text-xs text-slate-500">{w.exercises.length} Exercises</p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;
