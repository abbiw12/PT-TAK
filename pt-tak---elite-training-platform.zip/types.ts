
export type Role = 'host' | 'user';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  avatar?: string;
}

export interface Exercise {
  id: string;
  name: string;
  sets: number;
  reps: string;
  duration?: string;
  rest?: string;
  notes?: string;
}

export interface Workout {
  id: string;
  title: string;
  day: string; // e.g., "Monday"
  exercises: Exercise[];
}

export interface TrainingProgram {
  id: string;
  title: string;
  description: string;
  hostId: string;
  workouts: Workout[];
  assignedUserIds: string[];
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  durationWeeks: number;
}

export interface CompletionRecord {
  id: string;
  userId: string;
  workoutId: string;
  programId: string;
  date: string;
  completed: boolean;
  notes?: string;
}

export interface ProgressData {
  date: string;
  completions: number;
}
